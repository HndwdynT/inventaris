
<?php $__env->startSection('title', 'Edit Data'); ?>
<?php $__env->startSection('navhead','Data'); ?>
<?php $__env->startSection('container'); ?>
<div class="row">
  <div class="col-lg-15">
    <div class="card">
      <div class="card-body">
        <div class="card"></div>
        <form method="POST" action="<?php echo e(route('inventaris.update', $inventaris->id)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
            <div class="row mb-3">
              <label for="kode" class="col-sm-2 col-form-label">Kode Barang</label>
              <div class="col-sm-5">
                <input type="text" class="form-control" id="kode" name="kode" value="<?php echo e($inventaris->kode_barang); ?>">
              </div>
              <div class="col-sm-5">
                <input type="number" class="form-control" id="awalKode" name="awalKode" placeholder="Angka Awal Kode" value="<?php echo e($inventaris->awalKode); ?>">
              </div>
            </div>
            <div class="row mb-3">
              <label for="nama" class="col-sm-2 col-form-label">Nama Barang</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($inventaris->nama_barang); ?>">
              </div>
            </div>
            <div class="row mb-3">
              <label for="jumlah" class="col-sm-2 col-form-label">Jumlah Barang</label>
              <div class="col-sm-10">
                <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?php echo e($inventaris->jumlah_barang); ?>">
              </div>
            </div>
            <div class="row mb-3">
              <label for="tahun" class="col-sm-2 col-form-label">Tahun Pengadaan</label>
              <div class="col-sm-10">
                <input type="date" class="form-control" id="tahun" name="tahun" value="<?php echo e($inventaris->tahun_pengadaan); ?>">
              </div>
            </div>
            <div class="row mb-3">
              <label for="harga" class="col-sm-2 col-form-label">Harga</label>
              <div class="col-sm-10">
                <input type="number" class="form-control" id="harga" name="harga" value="<?php echo e($inventaris->harga_beli); ?>">
              </div>
            </div>
            <div class="row mb-3">
              <label for="sumberDana" class="col-sm-2 col-form-label">Sumber Dana</label>
              <div class="col-sm-10">
                <select class="form-control" id="sumberDana" name="sumberDana">
                  <option value="BOS" <?php echo e($inventaris->sumber_dana == 'BOS' ? 'selected' : ''); ?>>BOS</option>
                  <option value="APBD" <?php echo e($inventaris->sumber_dana == 'APBD' ? 'selected' : ''); ?>>APBD</option>
                  <option value="APBN" <?php echo e($inventaris->sumber_dana == 'APBN' ? 'selected' : ''); ?>>APBN</option>
                </select>
              </div>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary">Simpan</button>
              <button type="reset" class="btn btn-secondary">Ulang</button>
              <a href="<?php echo e(route('inventaris.index')); ?>" class="btn btn-danger">Batal</a>
            </div>
           </form><!-- End Horizontal Form -->
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris\resources\views/inventaris/edit.blade.php ENDPATH**/ ?>