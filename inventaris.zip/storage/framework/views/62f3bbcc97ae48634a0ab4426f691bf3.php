
<?php $__env->startSection('title', 'Sarana'); ?>
<?php $__env->startSection('navhead','Data'); ?>
<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-lg-15">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Example Card</h5>
          <p>This is an examle page with no contrnt. You can use it as a starter for your custom pages.</p>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris\resources\views/sarana.blade.php ENDPATH**/ ?>