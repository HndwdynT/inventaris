
<?php $__env->startSection('title', 'Inventaris'); ?>
<?php $__env->startSection('navhead', 'Data'); ?>
<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-lg-15">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><a class="btn btn-primary" href="<?php echo e(route('inventaris.add')); ?>"> Tambah Data</a></h5>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Jumlah Barang</th>
                            <th>Harga Beli</th>
                            <th>Tahun Pengadaan</th>
                            <th>Sumber Dana</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $inventaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($barang->kode_barang); ?></td>
                            <td><?php echo e($barang->nama_barang); ?></td>
                            <td><?php echo e($barang->jumlah_barang); ?></td>
                            <td><?php echo e($barang->harga_beli); ?></td>
                            <td><?php echo e($barang->tahun_pengadaan); ?></td>
                            <td><?php echo e($barang->sumber_dana); ?></td>
                            <td>
                                <div class="d-flex justify-content-start">
                                    <a href="<?php echo e(route('inventaris.edit', $barang->id)); ?>" class="btn btn-success mr-2">Edit</a>
                                    <form action="<?php echo e(route('inventaris.delete', $barang->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">Barang inventaris tidak tersedia.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventaris\resources\views\inventaris\index.blade.php ENDPATH**/ ?>